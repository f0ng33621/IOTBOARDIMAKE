from machine import Pin, PWM
import time

Buzzer_Pin = Pin(32,Pin.OUT)

buzzer = PWM(Buzzer_Pin, freq=1674, duty=1000)
time.sleep(1)
buzzer = PWM(Buzzer_Pin, freq=627, duty=1000)
time.sleep(1)

buzzer.deinit()