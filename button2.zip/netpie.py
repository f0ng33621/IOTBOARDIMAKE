import network
from machine import Pin
from simple import MQTTClient
from neopixel import NeoPixel
import dht
import json
import machine
import time


d = dht.DHT11(machine.Pin(13))

button1 = Pin(15, Pin.IN, Pin.PULL_UP)
button2 = Pin(2, Pin.IN, Pin.PULL_UP)
button3 = Pin(0, Pin.IN, Pin.PULL_UP)
button4 = Pin(4, Pin.IN, Pin.PULL_UP)

Relay1 = Pin(14,Pin.OUT)
Relay2 = Pin(27,Pin.OUT)

pin = Pin(23, Pin.OUT)
np = NeoPixel(pin, 8)

wlan = network.WLAN(network.STA_IF)
wlan.active(True)
print('Wifi Connecting...')
wlan.connect('iMakeEDU','imake1234')
while not wlan.isconnected():
    pass # pass this loop until wlan.isconnected is True

print('Wifi Connected!')
print(wlan.ifconfig())

MQTT_Client_ID = '36c68204-b8a2-40f4-a7a6-701dfc3cdbb6'
MQTT_Token = 'AYtsQWSJhpDGAkY2GFpZJKuWhbSfYhRr'
MQTT_Secret = '2_87Xr5cxUF2BOXedviHQmEo0L0fg57m'
MQTT_Broker = 'mqtt.netpie.io'
# Create Netpie profile
client = MQTTClient(MQTT_Client_ID, MQTT_Broker,user=MQTT_Token, password=MQTT_Secret)

# connect to netpie
client.connect()

while True:
    d.measure()
    temp = d.temperature()
    hum = d.humidity()
    Btn1_state = button1.value()
    Btn2_state = button2.value()
    Btn3_state = button3.value()
    Btn4_state = button4.value()
    
    Relay1.value(0)
    client.publish('@shadow/data/update',
                json.dumps({
                    'data' : {
                        'Relay1' : 'OFF'
                       }
                    }))
    
    if Btn1_state == 0:
        np[0] = (20,0,0)
        np.write()
        time.sleep(0.5)
        np[0] = (0,0,0)
        np.write()
        Relay1.value(1)
        print(Relay1)
        client.publish('@shadow/data/update',
                   json.dumps({
                       'data' : {
                           'Relay1' : 'ON'
                           }
                        }))
        
    print('Temperature:',temp,'Humidity:',hum)
    client.publish('@shadow/data/update',
                   json.dumps({
                       'data' : {
                           'temperature' : temp,
                           'Humidity' : hum,
                           }
                       
                       }))
    time.sleep(0.5)
