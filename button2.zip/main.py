
import network #! Library ที่ Import มาต้องไปลองใน Thonny อีกรอบ
import socket 
from simple import MQTTClient
from neopixel import NeoPixel
import dht
import json
import machine
import time
from machine import Pin, PWM



wlan = network.WLAN(network.STA_IF)
wlan.active(True)
print('Wifi Connecting...')
wlan.connect('iMakeEDU','imake1234')
while not wlan.isconnected():
    pass 

print('Wifi Connected!')
print(wlan.ifconfig())


MQTT_Client_ID = '36c68204-b8a2-40f4-a7a6-701dfc3cdbb6'
MQTT_Token = 'AYtsQWSJhpDGAkY2GFpZJKuWhbSfYhRr'
MQTT_Secret = '2_87Xr5cxUF2BOXedviHQmEo0L0fg57m'
MQTT_Broker = 'mqtt.netpie.io'

# todo 1.1 ใช้ sensor ตรวจว่ามีคนที่กำลังจะเดินเข้าไปในเขตเส้นเหลืองหรือเปล่า
#* def นี้ได้มาจาก https://randomnerdtutorials.com/micropython-interrupts-esp32-esp8266/
def YellowLine(pin): #? มาใส่เลข port Motion sensor ไม่ทราบว่าเกี่ยวกับ adc มั้ย
    while True :
        pir = Pin(14, Pin.OUT)
        resultMo = pir.irq(trigger=Pin.IRQ_RISING, handler=handle_interrupt) #ใช้ได้อีกตัว>> Pin.IRQ_FALLING: to trigger the interrupt whenever the pin goes from HIGH to LOW;
        print(resultMo) #check result ที่ได้

        if resultMo == '': # todo กำหนดค่าที่ได้หลังจากทดสอบ ผลอยู่ใน resultMo 
            



# todo 2 ถ้ามีคนตกลงไปข้างล่าง <<< ไปใช้ open cv ดึงรูปจาก iriun webcam
#! เช็คด้วยว่าถ้า update main.py ไปลงบอร์ด แล้วมันจะยังจับกล้องได้อยู่หรือเปล่า 
#* คำแนะนำจากอาจารย์มะ จะต้องมี 3 ส่วน 1.บอร์ดปล่อยให้รันออนไลน์ไปใช้ในการเช็คคนที่จะเข้าเส้นเหลือง 2.Link Webcam เข้าopencvในคอม 3.ส่งต่อไปที่บอร์ด




# todo 3 แจ้งเหตุไปยัง รปภ โดยใช้ gui ที่ควบคุมบอร์ดตัวนี้อยู่ (แบบ Local)



# todo 4 ส่ง ข้อมูลเข้าไปบนเว็บในกรณีสมมุติ (MQTT)คือส่งไปที่ ห้องศูนย์ควบการเดินรถเพื่อที่จะสามารถปรับเปลี่ยนตารางเดินรถให้กระทบผู้โดยสารน้อยที่สุด


# todo 5 สั่งบันไดทำงาน 

#todo 6 เก็บบันไดถ้ามีขบวนรถเข้ามาในระยะที่เก็บบันไดทัน + ให้สั่งจากคอมที่สถานีในการเก็บได้เอง